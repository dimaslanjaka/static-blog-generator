-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 06, 2005 at 09:09 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_myrewriter`
--

-- --------------------------------------------------------

--
-- Table structure for table `en_sinonim`
--

CREATE TABLE IF NOT EXISTS `en_sinonim` (
  `number` int(5) NOT NULL AUTO_INCREMENT,
  `word1` varchar(50) NOT NULL,
  `word2` varchar(50) NOT NULL,
  PRIMARY KEY (`number`),
  UNIQUE KEY `word1` (`word1`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `en_sinonim`
--

INSERT INTO `en_sinonim` (`number`, `word1`, `word2`) VALUES
(1, 'read', 'keep reading'),
(2, 'variety', 'multiplicity'),
(3, 'unique', 'unequaled'),
(4, 'amazing', 'awesome'),
(5, 'everyone', 'anybody'),
(6, 'find', 'get'),
(7, 'search', 'find'),
(8, 'make', 'create'),
(9, 'definitely', 'absolutely'),
(10, 'experience', 'knowledge'),
(11, 'rarely', 'infrequently'),
(12, 'after', 'behind'),
(13, 'understand', 'know'),
(14, 'quick', 'fast'),
(15, 'arrival', 'appearance'),
(16, 'loyal', 'supportive'),
(17, 'better', 'improved'),
(18, 'paid', 'gainful'),
(19, 'great', 'wonderful'),
(20, 'finished', 'done'),
(21, 'wanted', 'desirable'),
(22, 'dye', 'color'),
(23, 'collection', 'portfolio'),
(24, 'sparkling', 'fizzing'),
(25, 'shimmering', 'glittering'),
(26, 'however', 'nevertheless'),
(27, 'durable', 'enduring'),
(28, 'when', 'once'),
(29, 'actually', 'truly'),
(30, 'put', 'place'),
(31, 'attached', 'tied'),
(32, 'trendy', 'voguish'),
(33, 'said', 'told'),
(34, 'greeted', 'received'),
(35, 'try', 'test'),
(36, 'tried', 'tested'),
(37, 'entire', 'whole'),
(38, 'can', 'may'),
(39, 'shimmer', 'glitter'),
(40, 'really', 'truly'),
(41, 'clip', 'snip'),
(42, 'easy', 'simple'),
(43, 'across', 'astride'),
(44, 'numerous', 'several'),
(45, 'sightings', 'unearthing'),
(46, 'sighting', 'unearthing'),
(47, 'glowing', 'blazing'),
(48, 'descending', 'downward'),
(49, 'above', 'over'),
(50, 'around', 'about'),
(51, 'naked', 'nude'),
(52, 'love', 'love very much');

-- --------------------------------------------------------

--
-- Table structure for table `id_sinonim`
--

CREATE TABLE IF NOT EXISTS `id_sinonim` (
  `number` int(5) NOT NULL AUTO_INCREMENT,
  `word1` varchar(50) NOT NULL,
  `word2` varchar(50) NOT NULL,
  PRIMARY KEY (`number`),
  UNIQUE KEY `word1` (`word1`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `id_sinonim`
--

INSERT INTO `id_sinonim` (`number`, `word1`, `word2`) VALUES
(2, 'berbohong', 'memainkan kata-kata'),
(3, 'bisa melakukan', 'dapat melakukan'),
(4, 'koleksi', 'kumpulan'),
(5, 'kiamat', 'akhir dunia'),
(6, 'datang', 'hadir'),
(7, 'kedatangan', 'kehadiran'),
(8, 'gila', 'tidak waras'),
(10, 'hobi', 'kesukaan'),
(11, 'hebat', 'kuat'),
(12, 'wanita', 'perempuan'),
(13, 'sapi', 'lembu'),
(15, 'ruko', 'rumah toko'),
(18, 'cewek', 'wanita'),
(19, 'naik', 'pergi keatas'),
(20, 'hai', 'halo'),
(21, 'oleh-olehnya', 'buah tangannya'),
(22, 'pergi', 'berangkat'),
(23, 'suka', 'menyukai'),
(24, 'kelamin', 'kemaluan'),
(25, 'raksasa', 'makhluk besar'),
(26, 'job', 'pekerjaan'),
(27, 'keperluan', 'kebutuhan'),
(28, 'tinggi', 'jangkung'),
(29, 'gembira', 'ceria'),
(31, 'aku', 'saya'),
(32, 'cowok', 'laki-laki'),
(33, 'bete', 'bosan'),
(39, 'kepentingan', 'keperluan'),
(41, 'babu', 'pembantu');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `nomor_telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user`, `password`, `nama_lengkap`, `nomor_telp`) VALUES
('yussan', 'rahasia', 'Yusuf Akhsan Hidayat', '+6285645777298');
