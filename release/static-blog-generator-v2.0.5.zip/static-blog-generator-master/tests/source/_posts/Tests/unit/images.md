---
date: 2013-12-26T15:46:49+00:00
title: Images
uuid: fff0d600-8a0b-4888-8e19-88bfb821dd11
lang: en
category:
  - uncategorized
tags: []
updated: 2013-12-26T15:46:49+00:00
author: Hexo
comments: true
wordcount: 6
description: Images - Hexo
subtitle: Images - Hexo
excerpt: Images - Hexo
url: https://hexo.io/Tests/unit/images.html
permalink: /Tests/unit/images.html
type: post
---

This is a image test post.

![](/assets/wallpaper-2572384.jpg)

![Caption](/assets/wallpaper-2311325.jpg)

![](/assets/wallpaper-878514.jpg)

![Small Picture](https://placehold.it/350x150.jpg)
