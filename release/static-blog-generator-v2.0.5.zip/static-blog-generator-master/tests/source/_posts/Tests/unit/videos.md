---
date: 2013-12-24T17:19:15+00:00
tags:
  - videos
title: Videos
uuid: 554cfab3-38e2-4888-8d92-0bd6b75931f9
lang: en
category:
  - uncategorized
updated: 2013-12-24T17:19:15+00:00
author: Hexo
comments: true
wordcount: 6
description: Videos - Hexo
subtitle: Videos - Hexo
excerpt: Videos - Hexo
url: https://hexo.io/Tests/unit/videos.html
permalink: /Tests/unit/videos.html
type: post
---

This is a video test post.

**Youtube**

<div class="video-container">
  <iframe src="https://www.youtube.com/embed/TIbZDRXM-Tg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" loading="lazy" allowfullscreen="true"></iframe>
</div>

**Vimeo**

{% vimeo 82090131 %}