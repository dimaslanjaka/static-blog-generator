---
date: 2013-12-24T17:16:18+00:00
photos:
  - /assets/wallpaper-2572384.jpg
  - /assets/wallpaper-2311325.jpg
  - /assets/wallpaper-878514.jpg
  - http://placehold.it/350x150.jpg
title: Gallery Post
uuid: d1d6712b-3644-4888-8e47-c87100c6663f
lang: en
category:
  - uncategorized
tags: []
updated: 2013-12-24T17:16:18+00:00
author: Hexo
comments: true
wordcount: 22
description: Gallery Post - Hexo
subtitle: Gallery Post - Hexo
excerpt: Gallery Post - Hexo
url: https://hexo.io/Tests/unit/gallery-post.html
permalink: /Tests/unit/gallery-post.html
type: post
---

This post contains 4 photos:

- Widescreen wallpaper
- Portrait photo
- Dual widescreen wallpaper
- Small photo

All photos should be displayed properly.

*From [Wallbase.cc](http://wallbase.cc)*