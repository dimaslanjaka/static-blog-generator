---
date: 2013-12-24T16:29:53+00:00
tags:
  - sample-tag
  - example-tag
  - this-is-tag
title: Tags
uuid: 189f63f2-7cd7-4888-8395-616517535630
lang: en
category:
  - uncategorized
updated: 2013-12-24T16:29:53+00:00
author: Hexo
comments: true
wordcount: 15
description: Tags - Hexo
subtitle: Tags - Hexo
excerpt: Tags - Hexo
url: https://hexo.io/Tests/unit/tags.html
permalink: /Tests/unit/tags.html
type: post
---

This post contains 3 tags. Make sure your theme can display all of the tags.