---
categories:
  - sample-category
  - example-category
  - this-is-category
date: 2013-12-24T16:30:09+00:00
title: Categories
uuid: af1b98ad-7f68-4888-8b84-d0b443e022b7
lang: en
category:
  - uncategorized
tags: []
updated: 2013-12-24T16:30:09+00:00
author: Hexo
comments: true
wordcount: 15
description: Categories - Hexo
subtitle: Categories - Hexo
excerpt: Categories - Hexo
url: https://hexo.io/Tests/unit/categories.html
permalink: /Tests/unit/categories.html
type: post
---

This post contains 3 categories. Make sure your theme can display all of the categories.