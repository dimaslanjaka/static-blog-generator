---
date: 2013-12-24T16:30:04+00:00
link: http://www.google.com/
title: Link Post
uuid: 4a31187d-cd42-4888-819e-0db1757c5045
lang: en
category:
  - uncategorized
tags: []
updated: 2013-12-24T16:30:04+00:00
author: Hexo
comments: true
wordcount: 18
description: Link Post - Hexo
subtitle: Link Post - Hexo
excerpt: Link Post - Hexo
url: https://hexo.io/Tests/unit/link-post.html
permalink: /Tests/unit/link-post.html
type: post
---

This is a link post. Clicking on the link should open [Google](http://www.google.com/) in a new tab or window.