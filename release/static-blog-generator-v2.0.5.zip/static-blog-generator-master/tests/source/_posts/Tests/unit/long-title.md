---
date: 2013-12-24T16:31:06+00:00
tags: []
title: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam justo
  turpis, tincidunt ac convallis id.
uuid: 323d429e-fe86-4888-89b4-08aad6f81a79
lang: en
category:
  - uncategorized
updated: 2013-12-24T16:31:06+00:00
author: Hexo
comments: true
wordcount: 12
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam
  justo turpis, tincidunt ac convallis id. - Hexo
subtitle: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam justo
  turpis, tincidunt ac convallis id. - Hexo
excerpt: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam justo
  turpis, tincidunt ac convallis id. - Hexo
url: https://hexo.io/Tests/unit/long-title.html
permalink: /Tests/unit/long-title.html
type: post
---

This post has a long title. Make sure the title displayed right.