---
date: 2013-12-24T16:44:13+00:00
link: http://www.google.com/
uuid: 6f3c8988-847e-4888-8c79-422f8e3a3844
lang: en
category:
  - uncategorized
tags: []
updated: 2013-12-24T16:44:13+00:00
author: Hexo
comments: true
wordcount: 31
description: undefined - Hexo
subtitle: undefined - Hexo
excerpt: undefined - Hexo
title: link-post-without-title.md
url: https://hexo.io/Tests/unit/link-post-without-title.html
permalink: /Tests/unit/link-post-without-title.html
type: post
---

This is a link post without a title. The title should be the link with or without protocol. Clicking on the link should open [Google](http://www.google.com/) in a new tab or window.