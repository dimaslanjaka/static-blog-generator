---
category:
  - post
description: this is post description
tags:
  - sample
title: post with description
uuid: 7211f82e-f2f1-4888-87e9-30195485371b
date: 2022-06-04T15:30:03+00:00
lang: en
updated: 2022-06-04T15:30:03+00:00
author: Hexo
comments: true
wordcount: 3
subtitle: this is post description
excerpt: this is post description
url: https://hexo.io/with-description.html
permalink: /with-description.html
type: post
---

post with description