import os from 'os';
const computerName = os.hostname();
console.log(computerName);
