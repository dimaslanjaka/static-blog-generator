import uuidv4 from '../../src/node/uuid';

console.clear();
for (let index = 0; index < 5; index++) {
  console.log(uuidv4());
}
