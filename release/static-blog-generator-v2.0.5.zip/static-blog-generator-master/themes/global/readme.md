# boilerplate global resources to used in template
| filename | usage description |
|---|---|
| adsense.ejs | lazy load adsense |
| seo.ejs | site metadata |
| disqus.ejs | lazy load disqus comment |
