downloaded from https://www.themezy.com/free-website-templates/89-iridium-free-responsive-blog-template

## Features
- seo improvement
- lazy load external js
- adsense supported
- infinite scroll archives
