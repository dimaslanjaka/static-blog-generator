/* script js shortcode */
console.log('hello world');
