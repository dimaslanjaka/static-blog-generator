---
date: 2013-12-24T23:29:53+07:00
tags:
  - sample-tag
  - example-tag
  - this-is-tag
title: Tags
uuid: 189f63f2-7cd7-4888-8395-616517535630
updated: 2022-06-03T14:58:47+07:00
lang: en
category:
  - Uncategorized
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 15
description: Tags - Website Manajemen Indonesia
subtitle: Tags - Website Manajemen Indonesia
excerpt: Tags - Website Manajemen Indonesia
url: https://www.webmanajemen.com/Tests/unit/tags.html
permalink: /Tests/unit/tags.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/Tests/unit/tags.md
---

This post contains 3 tags. Make sure your theme can display all of the tags.