---
date: 2013-12-26T22:46:49+07:00
title: Images
uuid: fff0d600-8a0b-4888-8e19-88bfb821dd11
updated: 2022-06-03T14:58:46+07:00
lang: en
category:
  - Uncategorized
tags: []
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 6
description: Images - Website Manajemen Indonesia
subtitle: Images - Website Manajemen Indonesia
excerpt: Images - Website Manajemen Indonesia
url: https://www.webmanajemen.com/Tests/unit/images.html
permalink: /Tests/unit/images.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/Tests/unit/images.md
---

This is a image test post.

![](/assets/wallpaper-2572384.jpg)

![Caption](/assets/wallpaper-2311325.jpg)

![](/assets/wallpaper-878514.jpg)

![Small Picture](https://placehold.it/350x150.jpg)
