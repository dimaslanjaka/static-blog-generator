---
date: 2013-12-24T23:44:13+07:00
link: http://www.google.com/
uuid: 6f3c8988-847e-4888-8c79-422f8e3a3844
updated: 2022-06-03T14:58:47+07:00
lang: en
category:
  - Uncategorized
tags: []
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 31
description: undefined - Website Manajemen Indonesia
subtitle: undefined - Website Manajemen Indonesia
excerpt: undefined - Website Manajemen Indonesia
title: link-post-without-title.md
url: https://www.webmanajemen.com/Tests/unit/link-post-without-title.html
permalink: /Tests/unit/link-post-without-title.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/Tests/unit/link-post-without-title.md
---

This is a link post without a title. The title should be the link with or without protocol. Clicking on the link should open [Google](http://www.google.com/) in a new tab or window.