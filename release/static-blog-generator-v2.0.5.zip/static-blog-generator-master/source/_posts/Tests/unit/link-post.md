---
date: 2013-12-24T23:30:04+07:00
link: http://www.google.com/
title: Link Post
uuid: 4a31187d-cd42-4888-819e-0db1757c5045
updated: 2022-06-03T14:58:47+07:00
lang: en
category:
  - Uncategorized
tags: []
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 18
description: Link Post - Website Manajemen Indonesia
subtitle: Link Post - Website Manajemen Indonesia
excerpt: Link Post - Website Manajemen Indonesia
url: https://www.webmanajemen.com/Tests/unit/link-post.html
permalink: /Tests/unit/link-post.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/Tests/unit/link-post.md
---

This is a link post. Clicking on the link should open [Google](http://www.google.com/) in a new tab or window.