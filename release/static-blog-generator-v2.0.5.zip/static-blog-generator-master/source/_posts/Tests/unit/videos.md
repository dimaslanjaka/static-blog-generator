---
date: 2013-12-25T00:19:15+07:00
tags:
  - videos
title: Videos
uuid: 554cfab3-38e2-4888-8d92-0bd6b75931f9
updated: 2022-06-03T14:58:47+07:00
lang: en
category:
  - Uncategorized
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 6
description: Videos - Website Manajemen Indonesia
subtitle: Videos - Website Manajemen Indonesia
excerpt: Videos - Website Manajemen Indonesia
url: https://www.webmanajemen.com/Tests/unit/videos.html
permalink: /Tests/unit/videos.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/Tests/unit/videos.md
---

This is a video test post.

**Youtube**

<div class="video-container">
  <iframe src="https://www.youtube.com/embed/TIbZDRXM-Tg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" loading="lazy" allowfullscreen="true"></iframe>
</div>

**Vimeo**

{% vimeo 82090131 %}