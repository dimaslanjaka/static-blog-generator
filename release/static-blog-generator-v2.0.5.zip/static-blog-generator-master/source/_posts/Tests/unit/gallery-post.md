---
date: 2013-12-25T00:16:18+07:00
photos:
  - /assets/wallpaper-2572384.jpg
  - /assets/wallpaper-2311325.jpg
  - /assets/wallpaper-878514.jpg
  - http://placehold.it/350x150.jpg
title: Gallery Post
uuid: d1d6712b-3644-4888-8e47-c87100c6663f
updated: 2022-06-03T14:58:46+07:00
lang: en
category:
  - Uncategorized
tags: []
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 22
description: Gallery Post - Website Manajemen Indonesia
subtitle: Gallery Post - Website Manajemen Indonesia
excerpt: Gallery Post - Website Manajemen Indonesia
url: https://www.webmanajemen.com/Tests/unit/gallery-post.html
permalink: /Tests/unit/gallery-post.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/Tests/unit/gallery-post.md
---

This post contains 4 photos:

- Widescreen wallpaper
- Portrait photo
- Dual widescreen wallpaper
- Small photo

All photos should be displayed properly.

*From [Wallbase.cc](http://wallbase.cc)*