---
date: 2013-12-24T17:49:32+07:00
tags:
  - hello-world
title: Hello World
uuid: b10a8db1-4e07-4888-8410-b7a99be72e3f
updated: 2022-06-03T14:58:46+07:00
lang: en
category:
  - Uncategorized
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 16
description: Hello World - Website Manajemen Indonesia
subtitle: Hello World - Website Manajemen Indonesia
excerpt: Hello World - Website Manajemen Indonesia
url: https://www.webmanajemen.com/Tests/unit/hello-world.html
permalink: /Tests/unit/hello-world.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/Tests/unit/hello-world.md
---

Welcome to [Hexo](http://zespia.tw/hexo)! This is your very first post. Check [documentation](http://zespia.tw/hexo/docs) to learn how to use.