---
category:
  - post
description: this is post description
tags:
  - sample
title: post with description
uuid: 7211f82e-f2f1-4888-87e9-30195485371b
date: 2022-06-06T10:13:21+07:00
lang: en
updated: 2022-06-06T10:13:21+07:00
author:
  name: Dimas Lanjaka
  link: https://www.webmanajemen.com/
  email: dimaslanjaka@gmail.com
  image:
    url: https://res.cloudinary.com/dimaslanjaka/image/fetch/https://imgdb.net/images/3600.jpg
    width: 1944
    height: 2592
  social_links:
    github: https://github.com/dimaslanjaka
    youtube: https://youtube.com/p/L3n4r0x
comments: true
wordcount: 3
subtitle: this is post description
excerpt: this is post description
url: https://www.webmanajemen.com/with-description.html
permalink: /with-description.html
type: post
source: /media/dimaslanjaka/DATA/Repositories/static-blog-generator/src-posts/with-description.md
---

post with description