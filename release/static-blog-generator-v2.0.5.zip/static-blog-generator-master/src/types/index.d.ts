export interface DynamicObject extends Object {
  [keys: string]: any;
}
