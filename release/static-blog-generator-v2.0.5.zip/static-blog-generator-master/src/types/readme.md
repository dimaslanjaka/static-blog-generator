# global config and typestrong
- json files: auto generated config
- ts files: global config shimmer
- d.ts files: global typings for typescripts