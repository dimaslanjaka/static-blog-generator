const overridableReplacements = [
  ['&', ' and '],
  ['🦄', ' unicorn '],
  ['♥', ' love '],
];

export default overridableReplacements;
