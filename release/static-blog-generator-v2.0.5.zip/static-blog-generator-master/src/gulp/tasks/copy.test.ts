import { copyPosts } from './copy';

copyPosts(null, 'Quiz.');
