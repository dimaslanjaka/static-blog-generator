import generateTags from './generate-tags';

generateTags('Blogging', 4);
