import fixExternalImages from './fix-external-images';

console.clear();
fixExternalImages();
