import gulp from 'gulp';

gulp.task('deploy-firebase', (done) => {
  console.log('DEPLOY FIREBASE NOT YET IMPLEMENTED');
  if (typeof done == 'function') done();
});
